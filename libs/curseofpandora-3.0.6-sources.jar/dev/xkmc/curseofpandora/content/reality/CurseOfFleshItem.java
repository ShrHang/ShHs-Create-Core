package dev.xkmc.curseofpandora.content.reality;

import dev.xkmc.curseofpandora.content.complex.AttrAdder;
import dev.xkmc.curseofpandora.content.complex.ISlotAdderItem;
import dev.xkmc.curseofpandora.content.complex.ListTickingToken;
import dev.xkmc.curseofpandora.content.complex.SlotAdder;
import dev.xkmc.curseofpandora.init.CurseOfPandora;
import dev.xkmc.curseofpandora.init.data.CoPConfig;
import dev.xkmc.curseofpandora.init.data.CoPLangData;
import dev.xkmc.l2core.capability.conditionals.TokenKey;
import dev.xkmc.l2serial.serialization.marker.SerialClass;
import dev.xkmc.l2serial.serialization.marker.SerialField;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;
import java.util.Set;

public class CurseOfFleshItem extends ISlotAdderItem<CurseOfFleshItem.Ticker> {

	private static final SlotAdder ADDER = SlotAdder.of("curse_of_flesh", CoPConfig.SERVER.curse.curseOfFleshSlot);
	private static final TokenKey<Ticker> KEY = new TokenKey<>(CurseOfPandora.MODID, "curse_of_flesh");
	private static final AttrAdder R = CursePandoraUtil.reality(KEY), S = CursePandoraUtil.spell(KEY);

	private static int getThreshold() {
		return CoPConfig.SERVER.curse.curseOfFleshThreshold.get();
	}

	private static int getDuration() {
		return CoPConfig.SERVER.curse.curseOfFleshDuration.get();
	}

	private static double getBonus() {
		return CoPConfig.SERVER.curse.curseOfFleshBonus.get();
	}

	public CurseOfFleshItem(Properties properties) {
		super(properties, Ticker::new, ADDER, R, S);
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> list, TooltipFlag flag) {
		list.add(CoPLangData.Reality.FLESH.get(getThreshold(), getDuration(), Math.round(getBonus() * 100))
				.withStyle(ChatFormatting.GRAY));
	}

	@SerialClass
	public static class Ticker extends ListTickingToken {

		private final Lim lim = new Lim(this);

		@SerialField
		public int maintain = 0;

		public Ticker() {
			super(List.of(ADDER, R, S));
		}

		@Override
		protected void removeImpl(Player player) {
			super.removeImpl(player);
			lim.removeImpl(player);
		}

		@Override
		public void tickImpl(Player player) {
			if (player.getFoodData().getFoodLevel() >= getThreshold()) {
				if (maintain < 100000000)
					maintain++;
			} else maintain = 0;
			super.tickImpl(player);
			lim.tickImpl(player);
		}

	}

	public static class Lim extends AttributeLimiter {

		private final Ticker ticker;

		protected Lim(Ticker ticker) {
			super(Attributes.MAX_HEALTH, "flesh");
			this.ticker = ticker;
		}

		@Override
		protected CursePandoraUtil.ValueConsumer curseMult(double finVal, CursePandoraUtil.Mult valMult) {
			return new CursePandoraUtil.BonusMult(ticker.maintain >= getDuration() * 60 * 20 ? 1 + getBonus() : 1);
		}

		public void tickImpl(Player player) {
			doAttributeLimit(player, Set.of(), false);
			if (player.getHealth() > player.getMaxHealth()) {
				player.setHealth(player.getMaxHealth());
			}
		}

	}

}


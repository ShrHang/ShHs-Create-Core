package dev.xkmc.curseofpandora.content.complex;

import java.util.function.Supplier;

public abstract class ISlotAdderItem<T extends BasePandoraToken> extends ITokenProviderItem<T> {

	public final IAttrAdder[] adder;

	public ISlotAdderItem(Properties properties, Supplier<T> sup, IAttrAdder... adder) {
		super(properties, sup);
		this.adder = adder;
	}

	public final IAttrAdder[] getSlotAdder() {
		return adder;
	}

}

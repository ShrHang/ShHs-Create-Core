package dev.xkmc.curseofpandora.content.sets.elemental;

import dev.xkmc.curseofpandora.content.complex.AttrAdder;
import dev.xkmc.curseofpandora.content.complex.BasePandoraToken;
import dev.xkmc.curseofpandora.content.complex.ITokenProviderItem;
import dev.xkmc.curseofpandora.event.ClientSpellText;
import dev.xkmc.curseofpandora.init.data.CoPConfig;
import dev.xkmc.curseofpandora.init.data.CoPLangData;
import dev.xkmc.curseofpandora.init.registrate.CoPAttrs;
import dev.xkmc.l2damagetracker.init.L2DamageTracker;
import dev.xkmc.l2serial.serialization.marker.SerialClass;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

public class CurseRedirection extends ITokenProviderItem<CurseRedirection.Data> {

	private static double getStat() {
		return CoPConfig.SERVER.elemental.curseRedirectionBonus.get();
	}

	private static int getIndexReq() {
		return CoPConfig.SERVER.elemental.curseRedirectionRealityIndex.get();
	}

	private static AttrAdder magic(Player player) {
		var reg = player.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
		int count = 0;
		for (var e : EquipmentSlot.values()) {
			if (e.isArmor()) {
				ItemStack stack = player.getItemBySlot(e);
				for (var ent : stack.getAllEnchantments(reg).keySet()) {
					if (ent.is(EnchantmentTags.CURSE)) count++;
				}
			}
		}
		double bonus = count * getStat();
		return AttrAdder.of("curse_redirection", L2DamageTracker.MAGIC_FACTOR,
				AttributeModifier.Operation.ADD_VALUE, () -> bonus);
	}

	private static AttrAdder spell(Player player) {
		var reg = player.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
		int count = 0;
		for (var e : EquipmentSlot.values()) {
			if (e.isArmor()) {
				ItemStack stack = player.getItemBySlot(e);
				for (var ent : stack.getAllEnchantments(reg).keySet()) {
					if (ent.is(EnchantmentTags.CURSE)) {
						count++;
						break;
					}
				}
			}
		}
		double bonus = count;
		return AttrAdder.of("curse_redirection", CoPAttrs.SPELL,
				AttributeModifier.Operation.ADD_VALUE, () -> bonus);
	}

	public CurseRedirection(Properties properties) {
		super(properties, Data::new);
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> list, TooltipFlag flag) {
		boolean pass = ClientSpellText.getReality(ctx.level()) >= getIndexReq();
		list.add(CoPLangData.IDS.REALITY_INDEX.get(getIndexReq())
				.withStyle(pass ? ChatFormatting.YELLOW : ChatFormatting.GRAY));
		list.add(Component.literal("- ").append(CoPLangData.Elemental.CURSE_1.get())
				.withStyle(pass ? ChatFormatting.DARK_AQUA : ChatFormatting.DARK_GRAY));
		list.add(Component.literal("- ").append(CoPLangData.Elemental.CURSE_2.get(
				Math.round(getStat() * 100)
		)).withStyle(pass ? ChatFormatting.DARK_AQUA : ChatFormatting.DARK_GRAY));
	}

	@Override
	public void tick(Player player) {
		if (player.getAttributeValue(CoPAttrs.REALITY) >= getIndexReq())
			super.tick(player);
	}

	@SerialClass
	public static class Data extends BasePandoraToken {

		@Override
		protected void removeImpl(Player player) {
			magic(player).removeImpl(player);
			spell(player).removeImpl(player);
		}

		@Override
		protected void tickImpl(Player player) {
			if (player.level().isClientSide()) return;
			magic(player).tickImpl(player);
			spell(player).tickImpl(player);
		}

	}

}

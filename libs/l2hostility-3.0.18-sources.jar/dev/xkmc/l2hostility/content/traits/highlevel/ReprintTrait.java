package dev.xkmc.l2hostility.content.traits.highlevel;

import dev.xkmc.l2complements.init.registrate.LCEnchantments;
import dev.xkmc.l2damagetracker.contents.attack.DamageData;
import dev.xkmc.l2damagetracker.contents.attack.DamageModifier;
import dev.xkmc.l2hostility.content.item.traits.ReprintHandler;
import dev.xkmc.l2hostility.content.logic.TraitEffectCache;
import dev.xkmc.l2hostility.content.traits.base.MobTrait;
import dev.xkmc.l2hostility.init.data.LHConfig;
import dev.xkmc.l2hostility.init.registrate.LHEnchantments;
import net.minecraft.ChatFormatting;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;

import java.util.List;

public class ReprintTrait extends MobTrait {

	public ReprintTrait(ChatFormatting format) {
		super(format);
	}

	@Override
	public void onHurtTarget(int level, LivingEntity attacker, DamageData.Offence cache, TraitEffectCache traitCache) {
		long total = 0;
		int maxLv = 0;
		var access = attacker.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
		for (var slot : EquipmentSlot.values()) {
			ItemStack dst = attacker.getItemBySlot(slot);
			ItemStack src = cache.getTarget().getItemBySlot(slot);
			var targetEnch = src.getAllEnchantments(access);
			for (var e : targetEnch.entrySet()) {
				int lv = e.getIntValue();
				maxLv = Math.max(maxLv, lv);
				if (lv >= 30) {
					total = -1;
				} else if (total >= 0) {
					total += 1L << (lv - 1);
				}
			}
			if (cache.getSource().getDirectEntity() == attacker)
				ReprintHandler.reprint(attacker.level().registryAccess(), dst, src);
		}
		int bypass = LHConfig.SERVER.reprintBypass.get();
		if (maxLv >= bypass) {
			ItemStack weapon = attacker.getItemBySlot(EquipmentSlot.MAINHAND);
			if (!weapon.isEmpty() && (weapon.isEnchanted() || weapon.isEnchantable())) {
				if (weapon.isPrimaryItemFor(LCEnchantments.VOID_TOUCH.holder())) {
					var map = new ItemEnchantments.Mutable(weapon.getAllEnchantments(access));
					map.set(LCEnchantments.VOID_TOUCH.holder(), 20);
					map.set(LHEnchantments.VANISH.holder(), 1);
					EnchantmentHelper.setEnchantments(weapon, map.toImmutable());
				}
			}
		}
		float factor = total >= 0 ? total : (float) Math.pow(2, maxLv - 1);
		cache.addHurtModifier(DamageModifier.multTotal(1 + (float) (LHConfig.SERVER.reprintDamage.get() * factor), getRegistryName()));
	}

	@Override
	public void addDetail(RegistryAccess access, List<Component> list) {
		list.add(Component.translatable(getDescriptionId() + ".desc",
						mapLevel(access, i -> Component.literal(Math.round(LHConfig.SERVER.reprintDamage.get() * i * 100) + "%")
								.withStyle(ChatFormatting.AQUA)))
				.withStyle(ChatFormatting.GRAY));
	}

}
